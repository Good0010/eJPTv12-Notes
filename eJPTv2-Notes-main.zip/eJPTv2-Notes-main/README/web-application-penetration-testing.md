# 3⃣ Web Application Penetration Testing

### Topics

1. [Intro to Web App Pentesting](web-application-penetration-testing/3.1-intro-to-web-app-pentesting.md)

> #### ❗ Disclaimer
>
> * **Never use tools and techniques on real IP addresses, hosts or networks without proper authorization!**
