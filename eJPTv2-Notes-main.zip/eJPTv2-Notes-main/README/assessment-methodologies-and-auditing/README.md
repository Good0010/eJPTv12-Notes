# 1⃣ Assessment Methodologies & Auditing

### Topics

1. [Information Gathering](1.1-information-gathering.md)
2. [Footprinting & Scanning](1.2-footprinting-and-scanning.md)
3. [Enumeration](1.3-enumeration/)
4. [Vulnerability Assessment](1.4-vulnerability-assessment.md)
5. [Auditing Fundamentals](1.5-auditing-fundamentals.md)

> #### ❗ Disclaimer
>
> **Never use tools and techniques on real IP addresses, hosts or networks without proper     authorization!**
>
> ❗_**Never run these techniques on un-authorized addresses**_
